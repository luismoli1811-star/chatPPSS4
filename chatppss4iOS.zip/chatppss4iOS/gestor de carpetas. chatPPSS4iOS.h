// gestor_de_carpetas_chatppss4iOS
// Versión iOS — chatPPSS4
// Gestiona rutas y ubicaciones en iPhone/iPad

#ifndef GESTOR_CARPETAS_IOS_H
#define GESTOR_CARPETAS_IOS_H

#include <string>
#include <vector>

namespace GestorCarpetas {

// Ruta principal donde se ubica la carpeta de juegos
inline std::string obtener_ruta_base() {
    // En iOS: carpeta "PS4" dentro de Archivos > chatPPSS4
    return "PS4/";
}

// Ruta completa a la carpeta de juegos
inline std::string obtener_carpeta_juegos() {
    return obtener_ruta_base();
}

// Extensiones reconocidas como archivos de juego
inline std::vector<std::string> formatos_juego() {
    return {
        ".iso", ".pkg", ".ps4", ".card4", ".xps4",
        ".4iP", ".dic-ps4", ".PS4-RiP", ".vpp", ".claveagameps4"
    };
}

// Extensiones de archivos de sistema/datos
inline std::vector<std::string> formatos_sistema() {
    return {
        ".sfo", ".dat", ".edat", ".rap", ".mnu",
        ".gp4", ".img", ".elf", ".self", ".sprx"
    };
}

// Extensiones comprimidas
inline std::vector<std::string> formatos_comprimidos() {
    return {
        ".zip", ".7z", ".rar", ".4z", ".xRAR"
    };
}

// Verifica si la carpeta de juegos existe
bool carpeta_juegos_existe();

// Crea la carpeta de juegos si no existe
bool crear_carpeta_juegos();

// Lista todos los juegos encontrados
std::vector<std::string> listar_juegos();

} // namespace GestorCarpetas

#endif

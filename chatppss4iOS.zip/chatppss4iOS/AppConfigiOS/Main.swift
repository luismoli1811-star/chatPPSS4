import SwiftUI

@main
struct chatPPSS4App: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegado
    
    var body: some Scene {
        WindowGroup {
            VistaPrincipal()
                .preferredColorScheme(.dark)
        }
    }
}

struct VistaPrincipal: View {
    var body: some View {
        TabView {
            GameLibraryView()
                .tabItem {
                    Image(systemName: "gamecontroller.fill")
                    Text("Juegos")
                }
            
            GestionPortadasView()
                .tabItem {
                    Image(systemName: "photo.on.rectangle.angled")
                    Text("Portadas")
                }
            
            AjustesView()
                .tabItem {
                    Image(systemName: "gearshape.fill")
                    Text("Ajustes")
                }
        }
        .accentColor(.blue)
    }
}

// Ajustes de la app
struct AjustesView: View {
    var body: some View {
        NavigationView {
            List {
                Section("Información") {
                    HStack {
                        Text("Versión")
                        Spacer()
                        Text("0.0.1 iOS")
                            .foregroundColor(.secondary)
                    }
                    HStack {
                        Text("Motor de traducción")
                        Spacer()
                        Text("chat64iOS")
                            .foregroundColor(.green)
                    }
                }
                
                Section("Rutas") {
                    Text("Carpeta de juegos → Archivos → chatPPSS4 → PS4")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            .navigationTitle("Ajustes")
        }
    }
}

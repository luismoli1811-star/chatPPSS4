# LibraryForwardingiOS 🌉

## Propósito
Puente entre el núcleo escrito en C++ y la interfaz en Swift.
Permite que todo el código de chat64iOS y el emulador sea llamado desde la app de forma nativa.

## Estructura
- `LibraryForwardingiOS-Bridging.h` — Declaraciones que Swift puede ver
- `LibraryForwardingiOS-Bridge.mm` — Convierte tipos entre C++ y Objective-C
- `LibraryForwardingiOS-Swift.swift` — Interfaz limpia para usar en las pantallas
- `module.modulemap` — Dice a Xcode cómo importar todo

## Uso desde Swift
```swift
// Iniciar el emulador
if EmuladorNativo.inicializar() {
    print("Motor: \(EmuladorNativo.nombreMotor)")
}

// Listar juegos
let juegos = GestorCarpetasNativo.buscarJuegos()
Versión
 
- chatPPSS4 — 0.0.1

- Plataforma: ARM64 / iOS 15.0+

- Motor: chat64iOS

---

### ✅ Tu carpeta completa quedará así:
LibraryForwardingiOS/
├── LibraryForwardingiOS-Bridging.h      ✅
├── LibraryForwardingiOS-Bridge.mm       ✅
├── LibraryForwardingiOS-Swift.swift     ✅
├── module.modulemap                     ✅
└── README.md

### 🔑 Nota importante para Xcode:
En la configuración del objetivo → **Build Settings** → busca:
- **Objective-C Bridging Header** → pon: `LibraryForwardingiOS/LibraryForwardingiOS-Bridging.h`
- **Defines Module** → `YES`

¿Así ya está todo listo para compilar? 🚀🎉

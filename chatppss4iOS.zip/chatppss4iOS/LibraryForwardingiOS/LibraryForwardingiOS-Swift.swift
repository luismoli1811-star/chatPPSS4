/**
 * @file LibraryForwardingiOS-Swift.swift
 * @brief Acceso desde Swift al puente — Código listo para usar
 * @details Aquí llamas a todo el núcleo como si fuera clases nativas de Swift
 */

import Foundation

// MARK: — Emulador
public struct EmuladorNativo {
    public static func inicializar() -> Bool {
        EmuladorBridge.inicializar()
    }
    
    public static var nombreMotor: String {
        EmuladorBridge.nombreMotor()
    }
    
    public static func cargarJuego(ruta: String) -> Bool {
        EmuladorBridge.cargarJuego(ruta)
    }
    
    public static func iniciarEjecucion() -> Bool {
        EmuladorBridge.iniciarEjecucion()
    }
    
    public static func pausar() {
        EmuladorBridge.pausar()
    }
    
    public static func reanudar() {
        EmuladorBridge.reanudar()
    }
    
    public static func detener() {
        EmuladorBridge.detener()
    }
    
    public static var estado: String {
        EmuladorBridge.estado()
    }
    
    public static func apagar() {
        EmuladorBridge.apagar()
    }
}

// MARK: — Gestor de Carpetas
public struct GestorCarpetasNativo {
    public static func buscarJuegos() -> [String] {
        GestorCarpetasBridge.buscarJuegos()
    }
    
    public static func crearCarpetaSiNoExiste() -> Bool {
        GestorCarpetasBridge.crearCarpetaSiNoExiste()
    }
    
    public static var rutaCarpetaJuegos: String {
        GestorCarpetasBridge.rutaCarpetaJuegos()
    }
    
    public static var carpetaExiste: Bool {
        GestorCarpetasBridge.carpetaExiste()
    }
}

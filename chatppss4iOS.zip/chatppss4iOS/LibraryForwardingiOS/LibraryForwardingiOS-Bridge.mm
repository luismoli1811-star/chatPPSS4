/**
 * @file LibraryForwardingiOS-Bridge.mm
 * @brief Implementación del puente — C++ ↔ Swift
 * @date Septiembre 2026
 */

#import "LibraryForwardingiOS-Bridging.h"
#import <Foundation/Foundation.h>

using namespace chatPPSS4::Core;

// MARK: — Wrapper del Emulador para Swift
@interface EmuladorBridge : NSObject
@end

@implementation EmuladorBridge

+ (BOOL)inicializar {
    return Emulador::instancia().inicializar();
}

+ (NSString *) _Nonnull nombreMotor {
    return [NSString stringWithUTF8String:Emulador::instancia().nombre_motor().c_str()];
}

+ (BOOL)cargarJuego:(NSString * _Nonnull)ruta {
    return Emulador::instancia().cargar_juego(std::string([ruta UTF8String]));
}

+ (BOOL)iniciarEjecucion {
    return Emulador::instancia().iniciar_ejecucion();
}

+ (void)pausar {
    Emulador::instancia().pausar();
}

+ (void)reanudar {
    Emulador::instancia().reanudar();
}

+ (void)detener {
    Emulador::instancia().detener();
}

+ (NSString * _Nonnull)estado {
    return [NSString stringWithUTF8String:Emulador::instancia().resumen_estado().c_str()];
}

+ (void)apagar {
    Emulador::instancia().apagar();
}

@end

// MARK: — Wrapper del Gestor de Carpetas
@interface GestorCarpetasBridge : NSObject
@end

@implementation GestorCarpetasBridge

+ (NSArray<NSString *> * _Nonnull)buscarJuegos {
    std::vector<std::string> lista = GestorCarpetas::listar_juegos();
    NSMutableArray *resultado = [NSMutableArray arrayWithCapacity:lista.size()];
    for (const auto& nombre : lista) {
        [resultado addObject:[NSString stringWithUTF8String:nombre.c_str()]];
    }
    return resultado;
}

+ (BOOL)crearCarpetaSiNoExiste {
    return GestorCarpetas::crear_carpeta_juegos();
}

+ (NSString * _Nonnull)rutaCarpetaJuegos {
    return [NSString stringWithUTF8String:GestorCarpetas::obtener_ruta_carpeta_juegos().c_str()];
}

+ (BOOL)carpetaExiste {
    return GestorCarpetas::carpeta_juegos_existe();
}

@end

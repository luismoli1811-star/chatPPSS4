/**
 * @file LibraryForwardingiOS-Bridging.h
 * @brief Puente entre C++ y Swift — Cabeceras expuestas
 * @details Swift no ve C++ directamente, así que se expone mediante Objective-C
 */

#ifndef LibraryForwardingiOS_Bridging_h
#define LibraryForwardingiOS_Bridging_h

#import <Foundation/Foundation.h>

// Importar el núcleo del emulador
#import "chatPPSS4iOS.core.h"

// Importar el gestor de carpetas
#import "gestor_de_carpetas_chatppss4iOS.h"

// Importar la capa de traducción nativa
#import "chat64ios.h"

#endif /* LibraryForwardingiOS_Bridging_h */

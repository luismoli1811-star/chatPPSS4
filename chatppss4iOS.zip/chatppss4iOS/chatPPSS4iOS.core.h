#ifndef CHATPPSS4_IOS_CORE_H
#define CHATPPSS4_IOS_CORE_H

/**
 * @file chatPPSS4iOS.core.h
 * @brief Núcleo principal del emulador chatPPSS4 — Versión iOS
 * @details Adaptación para iPhone: usa chat64iOS en lugar de FEX/Box64
 * @version 0.0.1
 * @date Septiembre 2026
 */

#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>
#include <functional>

// Capa de traducción nativa para iOS
#include "chat64ios.h"

namespace chatPPSS4 {
namespace Core {

// Versión
constexpr const char* NOMBRE = "chatPPSS4";
constexpr const char* VERSION = "0.0.1-iOS";
constexpr const char* PLATAFORMA = "ARM64-iOS";

// Estado del emulador
enum class Estado {
    NoInicializado,
    Listo,
    Cargando,
    Ejecutando,
    Pausado,
    Error
};

// Información del juego cargado
struct JuegoInfo {
    std::string titulo;
    std::string id_ps4;
    std::string ruta_archivo;
    std::string formato;
    uint64_t tamano_bytes;
    bool es_encriptado;
};

// Núcleo principal
class Emulador {
public:
    static Emulador& instancia();

    // Ciclo de vida
    bool inicializar();
    void apagar();
    Estado estado() const;

    // Carga y ejecución
    bool cargar_juego(const std::string& ruta);
    bool iniciar_ejecucion();
    void pausar();
    void reanudar();
    void detener();

    // Información
    const JuegoInfo& juego_actual() const;
    std::string resumen_estado() const;

    // Motor de traducción
    bool motor_traduccion_inicializado() const;
    std::string nombre_motor() const { return "chat64iOS"; }

private:
    Emulador();
    ~Emulador();
    Emulador(const Emulador&) = delete;
    Emulador& operator=(const Emulador&) = delete;

    Estado m_estado;
    JuegoInfo m_juego;
    bool m_motor_listo;
    bool m_ejecutando;
};

// Utilidades
std::vector<std::string> buscar_juegos_en_carpeta();
bool crear_carpeta_juegos_si_no_existe();
std::string obtener_ruta_carpeta_juegos();

} // namespace Core
} // namespace chatPPSS4

#endif // CHATPPSS4_IOS_CORE_H

#include "gestor_de_carpetas_chatppss4iOS.h"
#include <dirent.h>
#include <sys/stat.h>
#include <cstring>

namespace GestorCarpetas {

bool carpeta_juegos_existe() {
    struct stat st;
    return stat(obtener_carpeta_juegos().c_str(), &st) == 0;
}

bool crear_carpeta_juegos() {
    if (carpeta_juegos_existe()) return true;
    return mkdir(obtener_carpeta_juegos().c_str(), 0755) == 0;
}

std::vector<std::string> listar_juegos() {
    std::vector<std::string> lista;
    std::string ruta = obtener_carpeta_juegos();
    
    DIR* dir = opendir(ruta.c_str());
    if (!dir) return lista;
    
    std::vector<std::string> ext_juego = formatos_juego();
    
    struct dirent* entrada;
    while ((entrada = readdir(dir)) != nullptr) {
        if (entrada->d_type == DT_REG) {
            std::string nombre = entrada->d_name;
            for (const auto& ext : ext_juego) {
                if (nombre.size() >= ext.size() &&
                    nombre.substr(nombre.size() - ext.size()) == ext) {
                    lista.push_back(nombre);
                    break;
                }
            }
        }
    }
    closedir(dir);
    return lista;
}

} // namespace GestorCarpetas

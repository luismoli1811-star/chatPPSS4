import SwiftUI
import Foundation

// MARK: - Modelo de Portada
struct PortadaJuego: Identifiable {
    let id = UUID()
    let nombreArchivo: String
    let nombreJuego: String
    let rutaImagen: URL?
    let colorDominante: String?
}

// MARK: - Gestor de Portadas
class CoverManager: ObservableObject {
    static let compartido = CoverManager()
    
    @Published var portadas: [String: PortadaJuego] = [:]
    
    private let carpetaPortadas: URL
    private let carpetaJuegos: URL
    
    private init() {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        carpetaJuegos = docs.appendingPathComponent("PS4", isDirectory: true)
        carpetaPortadas = docs.appendingPathComponent("PS4/Portadas", isDirectory: true)
        
        crearCarpetaSiNoExiste()
        cargarPortadasGuardadas()
    }
    
    // Crear carpeta de portadas si no existe
    private func crearCarpetaSiNoExiste() {
        do {
            try FileManager.default.createDirectory(at: carpetaPortadas, withIntermediateDirectories: true)
        } catch {
            print("[CoverManager] Error al crear carpeta: \(error)")
        }
    }
    
    // Cargar portadas ya guardadas
    func cargarPortadasGuardadas() {
        portadas.removeAll()
        
        do {
            let archivos = try FileManager.default.contentsOfDirectory(
                at: carpetaPortadas,
                includingPropertiesForKeys: [.isDirectoryKey]
            )
            for archivo in archivos where !archivo.hasDirectoryPath {
                procesarArchivoPortada(archivo)
            }
        } catch {
            print("[CoverManager] Error al leer portadas: \(error)")
        }
    }
    
    // Asociar portada con juego
    private func procesarArchivoPortada(_ url: URL) {
        let nombre = url.deletingPathExtension().lastPathComponent
        let ext = url.pathExtension.lowercased()
        
        guard ["png", "jpg", "jpeg", "webp"].contains(ext) else { return }
        
        let portada = PortadaJuego(
            nombreArchivo: url.lastPathComponent,
            nombreJuego: nombre,
            rutaImagen: url,
            colorDominante: nil
        )
        portadas[nombre] = portada
    }
    
    // Buscar portada para un juego
    func obtenerPortada(nombreJuego: String) -> PortadaJuego? {
        let limpio = limpiarNombre(nombreJuego)
        if let exacta = portadas[limpio] {
            return exacta
        }
        // Búsqueda parcial
        for (clave, portada) in portadas {
            if clave.contains(limpio) || limpio.contains(clave) {
                return portada
            }
        }
        return nil
    }
    
    // Eliminar extensión y espacios para comparar
    private func limpiarNombre(_ nombre: String) -> String {
        var limpio = nombre
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()
        for ext in [".iso", ".pkg", ".ps4", ".card4", ".xps4", ".4ip"] {
            if limpio.hasSuffix(ext) {
                limpio.removeLast(ext.count)
            }
        }
        return limpio.trimmingCharacters(in: .whitespacesAndNewlines)
    }
    
    // Agregar portada manualmente
    func agregarPortada(nombreJuego: String, desde rutaOrigen: URL) -> Bool {
        let nombreLimpio = limpiarNombre(nombreJuego)
        let destino = carpetaPortadas.appendingPathComponent("\(nombreLimpio).png")
        
        do {
            if FileManager.default.fileExists(atPath: destino.path) {
                try FileManager.default.removeItem(at: destino)
            }
            try FileManager.default.copyItem(at: rutaOrigen, to: destino)
            cargarPortadasGuardadas()
            return true
        } catch {
            print("[CoverManager] Error al copiar: \(error)")
            return false
        }
    }
    
    // Ruta de vista previa
    func rutaPortada(nombreJuego: String) -> URL? {
        obtenerPortada(nombreJuego: nombreJuego)?.rutaImagen
    }
}

// MARK: - Vista de Portada
struct PortadaJuegoView: View {
    let nombreJuego: String
    let rutaImagen: URL?
    let tamano: CGFloat
    
    init(nombreJuego: String, rutaImagen: URL? = nil, tamano: CGFloat = 100) {
        self.nombreJuego = nombreJuego
        self.rutaImagen = rutaImagen ?? CoverManager.compartido.rutaPortada(nombreJuego: nombreJuego)
        self.tamano = tamano
    }
    
    var body: some View {
        Group {
            if let ruta = rutaImagen,
               let uiImage = UIImage(contentsOfFile: ruta.path) {
                Image(uiImage: uiImage)
                    .resizable()
                    .scaledToFill()
            } else {
                // Portada generada si no hay imagen
                ZStack {
                    LinearGradient(
                        gradient: Gradient(colors: [.blue.opacity(0.7), .purple.opacity(0.6)]),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                    VStack(spacing: 4) {
                        Image(systemName: "gamecontroller.fill")
                            .font(.system(size: tamano * 0.35))
                            .foregroundColor(.white.opacity(0.9))
                        Text(nombreJuego.prefix(15))
                            .font(.system(size: tamano * 0.13, weight: .medium))
                            .foregroundColor(.white)
                            .lineLimit(2)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 4)
                    }
                }
            }
        }
        .frame(width: tamano * 0.75, height: tamano * 1.0)
        .cornerRadius(tamano * 0.08)
        .shadow(color: .black.opacity(0.25), radius: 4, x: 0, y: 2)
    }
}

// MARK: - Vista de Gestión de Portadas
struct GestionPortadasView: View {
    @StateObject private var gestor = CoverManager.compartido
    @State private var seleccionArchivo: Bool = false
    @State private var rutaOrigen: URL? = nil
    @State private var juegoSeleccionado: String = ""
    
    var body: some View {
        List {
            Section(header: Text("Portadas encontradas: \(gestor.portadas.count)")) {
                if gestor.portadas.isEmpty {
                    Text("Coloca imágenes en la carpeta PS4/Portadas desde la app Archivos")
                        .font(.caption)
                        .foregroundColor(.secondary)
                } else {
                    ForEach(gestor.portadas.keys.sorted(), id: \.self) { clave in
                        HStack {
                            if let portada = gestor.portadas[clave] {
                                PortadaJuegoView(nombreJuego: portada.nombreJuego, tamano: 60)
                                Text(portada.nombreJuego)
                                    .font(.system(size: 14))
                                Spacer()
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundColor(.green)
                            }
                        }
                    }
                }
            }
            
            Section(header: Text("Agregar portada manualmente")) {
                Button("Seleccionar imagen...") {
                    seleccionArchivo = true
                }
            }
        }
        .navigationTitle("Portadas")
        .sheet(isPresented: $seleccionArchivo) {
            // Selector de archivos para elegir imagen
        }
        .onAppear {
            gestor.cargarPortadasGuardadas()
        }
    }
}

// MARK: - Vista Previa
struct CoverManager_Previews: PreviewProvider {
    static var previews: some View {
        GestionPortadasView()
    }
}

#include "generador_arm64.h"
#include <cstring>

namespace chat64ios {

GeneradorARM64::GeneradorARM64(uint8_t* memoria_destino, size_t tamano)
    : destino(memoria_destino), tamano_max(tamano), posicion(0) {
    ultimas_banderas = {false, false, false, false};
}

size_t GeneradorARM64::bytes_escritos() const {
    return posicion;
}

void GeneradorARM64::escribir_arm64(uint32_t codigo) {
    if (posicion + 4 <= tamano_max) {
        destino[posicion++] = codigo & 0xFF;
        destino[posicion++] = (codigo >> 8) & 0xFF;
        destino[posicion++] = (codigo >> 16) & 0xFF;
        destino[posicion++] = (codigo >> 24) & 0xFF;
    }
}

RegistroMap GeneradorARM64::mapear_registro_x86(uint8_t codigo) {
    RegistroMap m;
    m.es_64bits = true;
    switch (codigo) {
        case 0: m.arm64_idx = 0; break;
        case 1: m.arm64_idx = 1; break;
        case 2: m.arm64_idx = 2; break;
        case 3: m.arm64_idx = 3; break;
        case 4: m.arm64_idx = 4; break;
        case 5: m.arm64_idx = 5; break;
        case 6: m.arm64_idx = 6; break;
        case 7: m.arm64_idx = 7; break;
        case 8: m.arm64_idx = 8; break;
        case 9: m.arm64_idx = 9; break;
        case 10: m.arm64_idx = 10; break;
        case 11: m.arm64_idx = 11; break;
        case 12: m.arm64_idx = 12; break;
        case 13: m.arm64_idx = 13; break;
        case 14: m.arm64_idx = 14; break;
        case 15: m.arm64_idx = 15; break;
        default: m.arm64_idx = 31; break;
    }
    return m;
}

void GeneradorARM64::emitir_mov_inmediato(uint8_t rd, uint64_t valor) {
    RegistroMap d = mapear_registro_x86(rd);
    if (valor <= 0xFFFF) {
        escribir_arm64(0xD2800000 | (d.arm64_idx << 5) | static_cast<uint32_t>(valor));
    } else {
        escribir_arm64(0xD2800000 | (d.arm64_idx << 5));
    }
}

void GeneradorARM64::emitir_mov_reg_a_reg(uint8_t rd, uint8_t rs) {
    RegistroMap d = mapear_registro_x86(rd);
    RegistroMap s = mapear_registro_x86(rs);
    escribir_arm64(0x2AA003E0 | (d.arm64_idx << 5) | (s.arm64_idx << 16));
}

void GeneradorARM64::emitir_cargar_desde_mem(uint8_t rd, uint8_t base, int32_t desp) {
    RegistroMap d = mapear_registro_x86(rd);
    RegistroMap b = mapear_registro_x86(base);
    if (desp >= 0 && desp <= 0xFF8 && (desp & 0x7) == 0) {
        uint32_t cod = 0xF9400000 | ((desp >> 3) << 10) | (b.arm64_idx << 16) | d.arm64_idx;
        escribir_arm64(cod);
    } else {
        escribir_arm64(0xF9400000 | (b.arm64_idx << 16) | d.arm64_idx);
    }
}

void GeneradorARM64::emitir_guardar_en_mem(uint8_t rs, uint8_t base, int32_t desp) {
    RegistroMap s = mapear_registro_x86(rs);
    RegistroMap b = mapear_registro_x86(base);
    if (desp >= 0 && desp <= 0xFF8 && (desp & 0x7) == 0) {
        uint32_t cod = 0xF9000000 | ((desp >> 3) << 10) | (b.arm64_idx << 16) | s.arm64_idx;
        escribir_arm64(cod);
    } else {
        escribir_arm64(0xF9000000 | (b.arm64_idx << 16) | s.arm64_idx);
    }
}

void GeneradorARM64::emitir_add_reg_reg(uint8_t rd, uint8_t rn, uint8_t rm, bool actualizar_banderas) {
    RegistroMap d = mapear_registro_x86(rd);
    RegistroMap a = mapear_registro_x86(rn);
    RegistroMap b = mapear_registro_x86(rm);
    if (actualizar_banderas) {
        escribir_arm64(0xAB000000 | d.arm64_idx | (a.arm64_idx << 5) | (b.arm64_idx << 16));
    } else {
        escribir_arm64(0x8B000000 | d.arm64_idx | (a.arm64_idx << 5) | (b.arm64_idx << 16));
    }
}

void GeneradorARM64::emitir_sub_reg_reg(uint8_t rd, uint8_t rn, uint8_t rm, bool actualizar_banderas) {
    RegistroMap d = mapear_registro_x86(rd);
    RegistroMap a = mapear_registro_x86(rn);
    RegistroMap b = mapear_registro_x86(rm);
    if (actualizar_banderas) {
        escribir_arm64(0xEB000000 | d.arm64_idx | (a.arm64_idx << 5) | (b.arm64_idx << 16));
    } else {
        escribir_arm64(0xCB000000 | d.arm64_idx | (a.arm64_idx << 5) | (b.arm64_idx << 16));
    }
}

void GeneradorARM64::emitir_cmp_reg_reg(uint8_t rn, uint8_t rm) {
    RegistroMap a = mapear_registro_x86(rn);
    RegistroMap b = mapear_registro_x86(rm);
    escribir_arm64(0xEB00001F | (a.arm64_idx << 5) | (b.arm64_idx << 16));
}

void GeneradorARM64::emitir_salto_relativo(int32_t desp) {
    int32_t instrucciones = desp / 4;
    uint32_t cod = 0x14000000 | (instrucciones & 0x03FFFFFF);
    escribir_arm64(cod);
}

void GeneradorARM64::emitir_salto_condicional(uint8_t tipo_x86, int32_t desp) {
    int32_t instrucciones = desp / 4;
    uint32_t cod_base;
    switch (tipo_x86) {
        case 0x74: cod_base = 0x54000000; break;
        case 0x75: cod_base = 0x54000001; break;
        case 0x72: cod_base = 0x54000002; break;
        case 0x73: cod_base = 0x54000003; break;
        case 0x7C: cod_base = 0x54000004; break;
        case 0x7D: cod_base = 0x54000005; break;
        case 0x7E: cod_base = 0x54000006; break;
        case 0x7F: cod_base = 0x54000007; break;
        default: return;
    }
    cod_base |= (instrucciones & 0x007FFFFF);
    escribir_arm64(cod_base);
}

void GeneradorARM64::emitir_push(uint8_t reg_x86) {
    RegistroMap r = mapear_registro_x86(reg_x86);
    uint32_t cod = 0xF81F0FF0 | (r.arm64_idx << 0);
    escribir_arm64(cod);
}

void GeneradorARM64::emitir_pop(uint8_t reg_x86) {
    RegistroMap r = mapear_registro_x86(reg_x86);
    uint32_t cod = 0xF8400FF0 | (r.arm64_idx << 0);
    escribir_arm64(cod);
}

void GeneradorARM64::emitir_llamada(int32_t desp) {
    int32_t instrucciones = desp / 4;
    uint32_t cod = 0x94000000 | (instrucciones & 0x03FFFFFF);
    escribir_arm64(cod);
}

void GeneradorARM64::emitir_retorno() {
    escribir_arm64(0xD65F03C0);
}

bool GeneradorARM64::traducir(const InstruccionX86& instr) {
    if (!instr.tiene_modrm) {
        switch (instr.codigo_op) {
            case 0xB8: case 0xB9: case 0xBA: case 0xBB:
            case 0xBC: case 0xBD: case 0xBE: case 0xBF:
                emitir_mov_inmediato(instr.codigo_op - 0xB8, instr.inmediato);
                break;
            case 0xEB:
                emitir_salto_relativo(static_cast<int8_t>(instr.desplazamiento));
                break;
            case 0xE9:
                emitir_salto_relativo(instr.desplazamiento);
                break;
            case 0x70: case 0x71: case 0x72: case 0x73:
            case 0x74: case 0x75: case 0x76: case 0x77:
            case 0x78: case 0x79: case 0x7A: case 0x7B:
            case 0x7C: case 0x7D: case 0x7E: case 0x7F:
                emitir_salto_condicional(instr.codigo_op, static_cast<int8_t>(instr.desplazamiento));
                break;
            case 0x50: case 0x51: case 0x52: case 0x53:
            case 0x54: case 0x55: case 0x56: case 0x57:
                emitir_push(instr.codigo_op - 0x50);
                break;
            case 0x58: case 0x59: case 0x5A: case 0x5B:
            case 0x5C: case 0x5D: case 0x5E: case 0x5F:
                emitir_pop(instr.codigo_op - 0x58);
                break;
            case 0xE8:
                emitir_llamada(instr.desplazamiento);
                break;
            case 0xC3:
                emitir_retorno();
                break;
            default:
                break;
        }
        return true;
    }

    if (instr.modrm_mod == 3) {
        switch (instr.codigo_op) {
            case 0x8B:
                emitir_mov_reg_a_reg(instr.modrm_reg, instr.modrm_rm);
                break;
            case 0x03:
                emitir_add_reg_reg(instr.modrm_reg, instr.modrm_reg, instr.modrm_rm, false);
                break;
            case 0x2B:
                emitir_sub_reg_reg(instr.modrm_reg, instr.modrm_reg, instr.modrm_rm, false);
                break;
            case 0x3B:
                emitir_cmp_reg_reg(instr.modrm_reg, instr.modrm_rm);
                break;
            case 0xC7:
                emitir_mov_inmediato(instr.modrm_rm, instr.inmediato);
                break;
        }
    } else {
        switch (instr.codigo_op) {
            case 0x8B:
                emitir_cargar_desde_mem(instr.modrm_reg, instr.modrm_rm, instr.desplazamiento);
                break;
            case 0x89:
                emitir_guardar_en_mem(instr.modrm_reg, instr.modrm_rm, instr.desplazamiento);
                break;
        }
    }
    return true;
}

}

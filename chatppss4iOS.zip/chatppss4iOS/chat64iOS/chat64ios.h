#ifndef CHAT64IOS_H
#define CHAT64IOS_H

#include <cstdint>
#include <cstddef>

namespace chat64ios {

bool inicializar();
void* traducir_bloque(const uint8_t* codigo_x86, size_t tamano);
void limpiar();

}
#endif

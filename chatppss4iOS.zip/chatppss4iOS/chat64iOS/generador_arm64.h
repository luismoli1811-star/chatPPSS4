#ifndef GENERADOR_ARM64_H
#define GENERADOR_ARM64_H

#include "decodificador.h"
#include <cstdint>
#include <cstddef>

namespace chat64ios {

struct RegistroMap {
    uint8_t arm64_idx;
    bool es_64bits;
};

struct Banderas {
    bool ZF;
    bool CF;
    bool SF;
    bool OF;
};

class GeneradorARM64 {
public:
    GeneradorARM64(uint8_t* memoria_destino, size_t tamano);
    
    bool traducir(const InstruccionX86& instr);
    size_t bytes_escritos() const;

private:
    uint8_t* destino;
    size_t tamano_max;
    size_t posicion;
    Banderas ultimas_banderas;
    
    RegistroMap mapear_registro_x86(uint8_t codigo);
    void escribir_arm64(uint32_t codigo);
    
    void emitir_mov_inmediato(uint8_t rd, uint64_t valor);
    void emitir_mov_reg_a_reg(uint8_t rd, uint8_t rs);
    void emitir_cargar_desde_mem(uint8_t rd, uint8_t base, int32_t desp);
    void emitir_guardar_en_mem(uint8_t rs, uint8_t base, int32_t desp);
    
    void emitir_add_reg_reg(uint8_t rd, uint8_t rn, uint8_t rm, bool actualizar_banderas = false);
    void emitir_sub_reg_reg(uint8_t rd, uint8_t rn, uint8_t rm, bool actualizar_banderas = false);
    void emitir_cmp_reg_reg(uint8_t rn, uint8_t rm);
    
    void emitir_salto_relativo(int32_t desp);
    void emitir_salto_condicional(uint8_t tipo_x86, int32_t desp);
    
    void emitir_push(uint8_t reg_x86);
    void emitir_pop(uint8_t reg_x86);
    void emitir_llamada(int32_t desp);
    void emitir_retorno();
};

}
#endif

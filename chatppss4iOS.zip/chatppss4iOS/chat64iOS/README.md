# chat64iOS 🍎
Capa de traducción x86-64 → ARM64 para Apple iOS

## Propósito
Box64 y FEX no existen para iOS. Esta capa traduce código
x86-64 a instrucciones ARM64 nativas que el iPhone ejecuta directo.

## Archivos
- chat64ios.h/cpp     → Interfaz principal
- decodificador.h/cpp → Lee y entiende código x86
- generador_arm64.h/cpp → Escribe equivalente en ARM64 nativo

## Uso
```cpp
#include "chat64ios.h"

int main() {
    chat64ios::inicializar();
    void* codigo_nativo = chat64ios::traducir_bloque(datos_x86, longitud);
    // Ejecutar codigo_nativo...
    chat64ios::limpiar();
}

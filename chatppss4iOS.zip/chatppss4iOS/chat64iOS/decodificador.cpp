#include "decodificador.h"

namespace chat64ios {

static int32_t leer_desplazamiento(const uint8_t* datos, int bytes) {
    if (bytes == 1) return static_cast<int8_t>(datos[0]);
    if (bytes == 4) {
        int32_t v = static_cast<int32_t>(datos[0]) | 
                   (static_cast<int32_t>(datos[1]) << 8) |
                   (static_cast<int32_t>(datos[2]) << 16) |
                   (static_cast<int32_t>(datos[3]) << 24);
        return v;
    }
    return 0;
}

static uint64_t leer_inmediato(const uint8_t* datos, int bytes, bool es_64bits) {
    uint64_t val = 0;
    if (bytes == 1) val = datos[0];
    else if (bytes == 4) {
        val = static_cast<uint32_t>(datos[0]) |
              (static_cast<uint32_t>(datos[1]) << 8) |
              (static_cast<uint32_t>(datos[2]) << 16) |
              (static_cast<uint32_t>(datos[3]) << 24);
    }
    else if (bytes == 8 && es_64bits) {
        val = static_cast<uint64_t>(datos[0]) |
              (static_cast<uint64_t>(datos[1]) << 8) |
              (static_cast<uint64_t>(datos[2]) << 16) |
              (static_cast<uint64_t>(datos[3]) << 24) |
              (static_cast<uint64_t>(datos[4]) << 32) |
              (static_cast<uint64_t>(datos[5]) << 40) |
              (static_cast<uint64_t>(datos[6]) << 48) |
              (static_cast<uint64_t>(datos[7]) << 56);
    }
    return val;
}

bool decodificar(const uint8_t* entrada, size_t tamano, InstruccionX86& out) {
    if (!entrada || tamano < 1) return false;

    size_t i = 0;
    out.es_64bits = false;
    out.tiene_prefijo_0f = false;
    out.tiene_modrm = false;
    out.modrm_mod = out.modrm_reg = out.modrm_rm = 0;
    out.desplazamiento = 0;
    out.inmediato = 0;

    while (i < tamano && (entrada[i] == 0x48 || entrada[i] == 0x49)) {
        out.es_64bits = true;
        out.bytes[i++] = entrada[i];
    }

    if (i < tamano && entrada[i] == 0x0F) {
        out.tiene_prefijo_0f = true;
        out.bytes[i++] = entrada[i];
    }

    if (i >= tamano) return false;
    out.codigo_op = entrada[i];
    out.bytes[i] = entrada[i];
    i++;
    out.longitud = i;

    bool necesita_modrm = false;
    int bytes_desplazamiento = 0;
    int bytes_inmediato = 0;

    switch (out.codigo_op) {
        case 0x00: case 0x01: case 0x02: case 0x03:
        case 0x08: case 0x09: case 0x0A: case 0x0B:
        case 0x10: case 0x11: case 0x12: case 0x13:
        case 0x18: case 0x19: case 0x1A: case 0x1B:
        case 0x20: case 0x21: case 0x22: case 0x23:
        case 0x28: case 0x29: case 0x2A: case 0x2B:
        case 0x30: case 0x31: case 0x32: case 0x33:
        case 0x38: case 0x39: case 0x3A: case 0x3B:
        case 0x63: case 0x85: case 0x8B: case 0x8F:
        case 0xC6: case 0xC7: case 0xD0: case 0xD1:
        case 0xD2: case 0xD3: case 0xF6: case 0xF7:
            necesita_modrm = true;
            break;

        case 0x80: case 0x81: case 0x82: case 0x83:
            necesita_modrm = true;
            bytes_inmediato = (out.codigo_op == 0x83) ? 1 : 4;
            break;

        case 0xB8: case 0xB9: case 0xBA: case 0xBB:
        case 0xBC: case 0xBD: case 0xBE: case 0xBF:
            bytes_inmediato = 4;
            break;

        case 0xEB: bytes_desplazamiento = 1; break;
        case 0xE8: case 0xE9: bytes_desplazamiento = 4; break;
    }

    if (necesita_modrm && i < tamano) {
        uint8_t modrm = entrada[i++];
        out.tiene_modrm = true;
        out.modrm_mod = (modrm >> 6) & 0b11;
        out.modrm_reg = (modrm >> 3) & 0b111;
        out.modrm_rm = modrm & 0b111;
        out.bytes[i-1] = modrm;

        if (out.modrm_mod == 1) bytes_desplazamiento = 1;
        if (out.modrm_mod == 2) bytes_desplazamiento = 4;
        if (out.modrm_mod == 0 && out.modrm_rm == 5) bytes_desplazamiento = 4;
    }

    if (bytes_desplazamiento > 0 && i + bytes_desplazamiento <= tamano) {
        out.desplazamiento = leer_desplazamiento(&entrada[i], bytes_desplazamiento);
        i += bytes_desplazamiento;
    }

    if (bytes_inmediato > 0 && i + bytes_inmediato <= tamano) {
        out.inmediato = leer_inmediato(&entrada[i], bytes_inmediato, out.es_64bits);
        i += bytes_inmediato;
    }

    out.longitud = i;
    if (out.longitud > tamano) out.longitud = tamano;
    return true;
}

}

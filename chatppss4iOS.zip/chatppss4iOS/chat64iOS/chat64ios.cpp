#include "chat64ios.h"
#include "decodificador.h"
#include "generador_arm64.h"
#include <iostream>
#include <sys/mman.h>

namespace chat64ios {

static bool inicializado = false;

bool inicializar() {
    if (inicializado) return true;
    std::cout << "[chat64iOS] Iniciando capa de traducción x86→ARM64 🍎\n";
    inicializado = true;
    return true;
}

void* traducir_bloque(const uint8_t* codigo_x86, size_t tamano) {
    if (!inicializado || !codigo_x86 || tamano == 0) {
        std::cerr << "[chat64iOS] No inicializado o datos inválidos\n";
        return nullptr;
    }

    size_t tamano_bufer = tamano * 4;
    void* memoria_nativa = mmap(nullptr, tamano_bufer,
                                PROT_READ | PROT_WRITE | PROT_EXEC,
                                MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);
    
    if (!memoria_nativa) {
        std::cerr << "[chat64iOS] Error al reservar memoria\n";
        return nullptr;
    }

    GeneradorARM64 generador(static_cast<uint8_t*>(memoria_nativa), tamano_bufer);
    
    size_t pos = 0;
    while (pos < tamano) {
        InstruccionX86 instr;
        if (!decodificar(codigo_x86 + pos, tamano - pos, instr)) {
            std::cerr << "[chat64iOS] No se pudo decodificar en posición " << pos << "\n";
            break;
        }
        
        generador.traducir(instr);
        pos += instr.longitud;
    }

    std::cout << "[chat64iOS] Traducido: " << tamano << " bytes x86 → " 
              << generador.bytes_escritos() << " bytes ARM64 nativo ✅\n";
    return memoria_nativa;
}

void limpiar() {
    inicializado = false;
    std::cout << "[chat64iOS] Finalizado\n";
}

}

#ifndef DECODIFICADOR_H
#define DECODIFICADOR_H

#include <cstdint>
#include <cstddef>

namespace chat64ios {

struct InstruccionX86 {
    uint8_t  bytes[15];
    uint8_t  longitud;
    uint16_t codigo_op;
    bool es_64bits;
    bool tiene_prefijo_0f;
    
    bool tiene_modrm;
    uint8_t modrm_mod;
    uint8_t modrm_reg;
    uint8_t modrm_rm;
    
    int32_t desplazamiento;
    uint64_t inmediato;
};

bool decodificar(const uint8_t* entrada, size_t tamano, InstruccionX86& out);

}
#endif

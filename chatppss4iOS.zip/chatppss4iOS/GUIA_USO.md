Guía de Uso — chatPPSS4IOS (Versión iOS) 📖🍎
 
Primeros pasos
 
1. Selecciona la carpeta donde tienes tus juegos de PS4 → carpeta  PS4  en Archivos

2. El motor de traducción ya viene configurado:

- ✅ chat64iOS → Traducción nativa x86→ARM64, optimizada para iPhone

- ⚡ Sin emulación lenta → el código corre directo en tu procesador

3. Toca un juego para iniciarlo
 
Controles táctiles
 
- Tocar el panel táctil → funciona como el del mando real de PS4

- Deslizar sobre el panel → movimientos del cursor/puntero

- Stick izquierdo → movimiento del personaje

- Stick derecho → cámara

- Botones de acción → △ ○ □ ×

- L1 / L2 / R1 / R2 → gatillos y botones superiores

- Botón PS → abre el menú del sistema

- Puedes conectar mando Bluetooth de PS4/PS5 para jugar 100% nativo 🎮
 
Formatos soportados
 
🎮 Formatos de juego (10):
 
1.  .iso          - Imagen de disco

2.  .pkg          - Paquete oficial de instalación

3.  .ps4          - Formato de emulador

4.  .card4        - Formato propio

5.  .xps4         - Formato extendido

6.  .4iP          - Formato de paquete

7.  .dic-ps4      - Formato comprimido/encriptado

8.  .PS4-RiP      - Juego ripeado

9.  .vpp          - Paquete de datos

10.  .claveagameps4  - Formato personalizado
 
📦 Archivos de datos y sistema (10):
 
11.  .sfo         - Metadatos del sistema

12.  .dat         - Archivo de datos

13.  .edat        - Datos encriptados

14.  .rap         - Archivo de licencia

15.  .mnu         - Archivo de menú

16.  .gp4         - Proyecto de paquete

17.  .img         - Imagen de disco/partición

18.  .elf         - Ejecutable

19.  .self        - Ejecutable firmado

20.  .sprx        - Módulo de sistema
 
🗜️ Formatos comprimidos (5):
 
21.  .zip 

22.  .7z 

23.  .rar 

24.  .4z          - Formato propio

25.  .xRAR        - Formato extendido
 
 
 
✅ Total: 25 formatos principales + 4 archivos de sistema = 29 en total
📂 Carpeta de juegos:  PS4  → colócala en la app Archivos → chatPPSS4iOS
 
 
 
📱 Versión iOS — Traducción nativa con chat64iOS
Última actualización: Septiembre 2026
Versión 0.0.1 — 🍎 Optimizada para iPhone
 
 
 
✅ Cambios respecto a la versión de Android:
 
- ❌ Ya no aparecen FEX ni Box64

- ✅ Aparece chat64iOS como motor de traducción nativo

- ✅ Menciona dónde poner la carpeta en iOS

- ✅ Agrega compatibilidad con mandos Bluetooth

- ✅ Todo igual que tu versión original, solo adaptado a iPhone 🍎
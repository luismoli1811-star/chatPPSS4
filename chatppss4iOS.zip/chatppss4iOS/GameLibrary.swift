import SwiftUI
import Foundation

struct GameLibraryView: View {
    @State private var juegos: [String] = []
    @State private var cargando = true
    @State private var seleccion: String? = nil
    
    // Ruta de la carpeta PS4 en la app de iOS
    private let carpetaJuegos: URL = {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("PS4", isDirectory: true)
    }()
    
    var body: some View {
        NavigationView {
            List {
                if cargando {
                    Section {
                        HStack {
                            ProgressView()
                            Text("Buscando juegos...")
                                .foregroundColor(.secondary)
                        }
                    }
                } else if juegos.isEmpty {
                    Section {
                        VStack(spacing: 12) {
                            Image(systemName: "folder")
                                .font(.system(size: 40))
                                .foregroundColor(.gray)
                            Text("No hay juegos")
                                .font(.headline)
                            Text("Coloca tus juegos en la carpeta PS4 desde la app Archivos")
                                .font(.caption)
                                .foregroundColor(.secondary)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 30)
                    }
                } else {
                    Section(header: Text("\(juegos.count) juegos encontrados")) {
                        ForEach(juegos, id: \.self) { juego in
                            Button {
                                seleccion = juego
                            } label: {
                                HStack {
                                    VStack(alignment: .leading) {
                                        Text(juego)
                                            .font(.system(size: 15, weight: .medium))
                                            .foregroundColor(.primary)
                                        if let formato = obtenerFormato(nombre: juego) {
                                            Text(formato)
                                                .font(.caption)
                                                .foregroundColor(.secondary)
                                        }
                                    }
                                    Spacer()
                                    Image(systemName: "play.circle.fill")
                                        .foregroundColor(.blue)
                                }
                            }
                        }
                    }
                }
            }
            .navigationTitle("Biblioteca")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: buscarJuegos) {
                        Image(systemName: "arrow.clockwise")
                    }
                }
            }
            .sheet(item: $seleccion) { juego in
                VistaDetalleJuego(nombreJuego: juego, rutaCompleta: carpetaJuegos.appendingPathComponent(juego).path)
            }
        }
        .navigationViewStyle(.stack)
        .onAppear(perform: buscarJuegos)
    }
    
    // Buscar juegos en la carpeta PS4
    private func buscarJuegos() {
        cargando = true
        juegos.removeAll()
        
        DispatchQueue.global(qos: .userInitiated).async {
            var encontrados: [String] = []
            
            do {
                let archivos = try FileManager.default.contentsOfDirectory(at: carpetaJuegos, includingPropertiesForKeys: nil)
                for archivo in archivos {
                    if esFormatoReconocido(nombre: archivo.lastPathComponent) {
                        encontrados.append(archivo.lastPathComponent)
                    }
                }
            } catch {
                print("[Biblioteca] Error al leer carpeta: \(error.localizedDescription)")
            }
            
            DispatchQueue.main.async {
                self.juegos = encontrados.sorted()
                self.cargando = false
            }
        }
    }
    
    // Verificar extensiones soportadas
    private func esFormatoReconocido(nombre: String) -> Bool {
        let ext = nombre.lowercased().split(separator: ".").last ?? ""
        let formatos = ["iso", "pkg", "ps4", "card4", "xps4", "4ip", "dic-ps4", "ps4-rip", "vpp", "claveagameps4"]
        return formatos.contains(String(ext))
    }
    
    // Obtener nombre del formato
    private func obtenerFormato(nombre: String) -> String? {
        let ext = nombre.split(separator: ".").last ?? ""
        return ext.isEmpty ? nil : ".\(ext)"
    }
}

// Vista detalle al tocar un juego
struct VistaDetalleJuego: View, Identifiable {
    let id = UUID()
    let nombreJuego: String
    let rutaCompleta: String
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Image(systemName: "gamecontroller.fill")
                    .font(.system(size: 60))
                    .foregroundColor(.blue)
                    .padding(.top, 30)
                
                Text(nombreJuego)
                    .font(.title2)
                    .fontWeight(.semibold)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
                
                Text("Listo para iniciar con chat64iOS")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                Spacer()
                
                Button(action: {
                    // Aquí se llama al núcleo para iniciar el juego
                    print("▶️ Iniciar: \(nombreJuego)")
                }) {
                    HStack {
                        Image(systemName: "play.fill")
                        Text("Iniciar Juego")
                            .fontWeight(.semibold)
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(12)
                    .padding(.horizontal, 20)
                }
                .padding(.bottom, 30)
            }
            .navigationTitle("Detalles")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Cerrar") {
                        // Cierra la hoja
                        DispatchQueue.main.async {
                            // Se gestiona desde la vista principal
                        }
                    }
                }
            }
        }
    }
}

// Preview
struct GameLibraryView_Previews: PreviewProvider {
    static var previews: some View {
        GameLibraryView()
    }
}

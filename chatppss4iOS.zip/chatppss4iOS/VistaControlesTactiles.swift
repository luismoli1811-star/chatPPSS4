import UIKit
import CoreGraphics

class VistaControlesTactiles: UIView {
    
    // MARK: — Botones y palancas
    private var botonX: UIImageView!
    private var botonCirculo: UIImageView!
    private var botonCuadrado: UIImageView!
    private var botonTriangulo: UIImageView!
    
    private var botonL1: UIImageView!
    private var botonL2: UIImageView!
    private var botonR1: UIImageView!
    private var botonR2: UIImageView!
    
    private var palancaIzquierda: UIImageView!
    private var palancaDerecha: UIImageView!
    
    // MARK: — Acción que se envía al emulador
    var alPresionarBoton: ((String, Bool) -> Void)?
    
    // MARK: — Inicialización
    override init(frame: CGRect) {
        super.init(frame: frame)
        configurarBotones()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        configurarBotones()
    }
    
    // MARK: — Colocar todos los controles
    private func configurarBotones() {
        backgroundColor = .clear
        isUserInteractionEnabled = true
        
        let tamanoBoton: CGFloat = 60
        let margenLado: CGFloat = 20
        let margenAbajo: CGFloat = 80
        
        // --- Botones lado derecho ---
        botonX = crearBoton(nombreImagen: "x.png", 
                            marco: CGRect(x: bounds.width - margenLado - tamanoBoton,
                                          y: bounds.height - margenAbajo - tamanoBoton,
                                          width: tamanoBoton, height: tamanoBoton),
                            id: "cross")
        
        botonCirculo = crearBoton(nombreImagen: "o.png",
                                  marco: CGRect(x: bounds.width - margenLado - tamanoBoton*2 - 15,
                                                y: bounds.height - margenAbajo - tamanoBoton,
                                                width: tamanoBoton, height: tamanoBoton),
                                  id: "circle")
        
        botonCuadrado = crearBoton(nombreImagen: "□.png",
                                   marco: CGRect(x: bounds.width - margenLado - tamanoBoton,
                                                 y: bounds.height - margenAbajo - tamanoBoton*2 - 15,
                                                 width: tamanoBoton, height: tamanoBoton),
                                   id: "square")
        
        botonTriangulo = crearBoton(nombreImagen: "△.png",
                                    marco: CGRect(x: bounds.width - margenLado - tamanoBoton*2 - 15,
                                                  y: bounds.height - margenAbajo - tamanoBoton*2 - 15,
                                                  width: tamanoBoton, height: tamanoBoton),
                                    id: "triangle")
        
        // --- Botones superiores L1 L2 R1 R2 ---
        botonL1 = crearBoton(nombreImagen: "btn_L1.png",
                             marco: CGRect(x: 20, y: 40, width: 80, height: 40), id: "L1")
        botonL2 = crearBoton(nombreImagen: "btn_L2.png",
                             marco: CGRect(x: 20, y: 90, width: 80, height: 40), id: "L2")
        botonR1 = crearBoton(nombreImagen: "btn_R1.png",
                             marco: CGRect(x: bounds.width - 100, y: 40, width: 80, height: 40), id: "R1")
        botonR2 = crearBoton(nombreImagen: "btn_R2.png",
                             marco: CGRect(x: bounds.width - 100, y: 90, width: 80, height: 40), id: "R2")
        
        // --- Palancas ---
        palancaIzquierda = UIImageView(frame: CGRect(x: 40, y: bounds.height - 180, width: 90, height: 90))
        palancaIzquierda.image = UIImage(named: "btn_stick_base.png")
        palancaIzquierda.contentMode = .scaleAspectFit
        palancaIzquierda.isUserInteractionEnabled = true
        addSubview(palancaIzquierda)
        
        palancaDerecha = UIImageView(frame: CGRect(x: bounds.width - 130, y: bounds.height - 180, width: 90, height: 90))
        palancaDerecha.image = UIImage(named: "btn_stick_base.png")
        palancaDerecha.contentMode = .scaleAspectFit
        palancaDerecha.isUserInteractionEnabled = true
        addSubview(palancaDerecha)
    }
    
    // MARK: — Ayudante para crear cada botón
    private func crearBoton(nombreImagen: String, marco: CGRect, id: String) -> UIImageView {
        let boton = UIImageView(frame: marco)
        boton.image = UIImage(named: nombreImagen)
        boton.contentMode = .scaleAspectFit
        boton.isUserInteractionEnabled = true
        boton.tag = id.hashValue
        addSubview(boton)
        return boton
    }
    
    // MARK: — Detectar toques
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        for toque in touches {
            let ubicacion = toque.location(in: self)
            if let boton = subviews.first(where: { $0.frame.contains(ubicacion) }) as? UIImageView {
                let nombreBoton = identificarBoton(boton)
                alPresionarBoton?(nombreBoton, true)
                boton.alpha = 0.7 // Efecto de presionado
            }
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesEnded(touches, with: event)
        for toque in touches {
            let ubicacion = toque.location(in: self)
            if let boton = subviews.first(where: { $0.frame.contains(ubicacion) }) as? UIImageView {
                let nombreBoton = identificarBoton(boton)
                alPresionarBoton?(nombreBoton, false)
                boton.alpha = 1.0
            }
        }
    }
    
    private func identificarBoton(_ vista: UIView) -> String {
        switch vista.tag {
        case "cross".hashValue: return "cross"
        case "circle".hashValue: return "circle"
        case "square".hashValue: return "square"
        case "triangle".hashValue: return "triangle"
        case "L1".hashValue: return "L1"
        case "L2".hashValue: return "L2"
        case "R1".hashValue: return "R1"
        case "R2".hashValue: return "R2"
        default: return "desconocido"
        }
    }
}

import UIKit

class VistaControlador: UIViewController {
    private var vistaControles: VistaControlesTactiles!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        
        // Vista donde se dibuja el juego
        let vistaJuego = UIView(frame: view.bounds)
        vistaJuego.backgroundColor = .clear
        view.addSubview(vistaJuego)
        
        // Agregar controles táctiles encima
        vistaControles = VistaControlesTactiles(frame: view.bounds)
        vistaControles.alPresionarBoton = { boton, presionado in
            // Aquí conectas con TU CÓDIGO C++ del emulador 💙
            print("Botón \(boton): \(presionado ? "PRESIONADO" : "SOLTADO")")
            // Llamada a tu función C++: enviarOrdenAlEmulador(boton, presionado)
        }
        view.addSubview(vistaControles)
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .all // Permite vertical y horizontal
    }
}

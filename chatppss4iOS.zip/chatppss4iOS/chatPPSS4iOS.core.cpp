#include "chatPPSS4iOS.core.h"
#include "gestor_de_carpetas_chatppss4iOS.h"
#include <iostream>

namespace chatPPSS4 {
namespace Core {

Emulador& Emulador::instancia() {
    static Emulador inst;
    return inst;
}

Emulador::Emulador()
    : m_estado(Estado::NoInicializado)
    , m_motor_listo(false)
    , m_ejecutando(false) {
}

Emulador::~Emulador() {
    apagar();
}

bool Emulador::inicializar() {
    if (m_estado != Estado::NoInicializado) return true;

    std::cout << "[" << NOMBRE << "] Iniciando versión " << VERSION << " en " << PLATAFORMA << "\n";

    // Inicializar capa de traducción nativa
    m_motor_listo = chat64ios::inicializar();
    if (!m_motor_listo) {
        std::cerr << "Error: No se pudo inicializar chat64iOS\n";
        m_estado = Estado::Error;
        return false;
    }

    // Preparar carpeta de juegos
    if (!crear_carpeta_juegos_si_no_existe()) {
        std::cout << "Aviso: No se pudo crear/verificar carpeta de juegos\n";
    }

    m_estado = Estado::Listo;
    std::cout << "[" << NOMBRE << "] ✅ Listo — Motor: " << nombre_motor() << "\n";
    return true;
}

void Emulador::apagar() {
    if (m_ejecutando) detener();
    if (m_motor_listo) {
        chat64ios::limpiar();
        m_motor_listo = false;
    }
    m_estado = Estado::NoInicializado;
}

Estado Emulador::estado() const {
    return m_estado;
}

bool Emulador::cargar_juego(const std::string& ruta) {
    if (m_estado != Estado::Listo && m_estado != Estado::Pausado) return false;

    m_estado = Estado::Cargando;
    m_juego.ruta_archivo = ruta;

    // Aquí se analiza el archivo y se extrae información
    // (se amplía según formatos soportados)

    m_estado = Estado::Listo;
    std::cout << "[" << NOMBRE << "] Juego cargado: " << ruta << "\n";
    return true;
}

bool Emulador::iniciar_ejecucion() {
    if (m_estado != Estado::Listo) return false;
    if (!m_motor_listo) return false;

    m_ejecutando = true;
    m_estado = Estado::Ejecutando;
    std::cout << "[" << NOMBRE << "] ▶️ Ejecutando...\n";
    return true;
}

void Emulador::pausar() {
    if (m_estado == Estado::Ejecutando) {
        m_estado = Estado::Pausado;
        std::cout << "[" << NOMBRE << "] ⏸️ Pausado\n";
    }
}

void Emulador::reanudar() {
    if (m_estado == Estado::Pausado) {
        m_estado = Estado::Ejecutando;
        std::cout << "[" << NOMBRE << "] ▶️ Reanudado\n";
    }
}

void Emulador::detener() {
    m_ejecutando = false;
    m_estado = Estado::Listo;
    std::cout << "[" << NOMBRE << "] ⏹️ Detenido\n";
}

const JuegoInfo& Emulador::juego_actual() const {
    return m_juego;
}

std::string Emulador::resumen_estado() const {
    switch (m_estado) {
        case Estado::NoInicializado: return "No inicializado";
        case Estado::Listo: return "Listo";
        case Estado::Cargando: return "Cargando juego...";
        case Estado::Ejecutando: return "Ejecutando";
        case Estado::Pausado: return "En pausa";
        case Estado::Error: return "Error";
    }
    return "Desconocido";
}

bool Emulador::motor_traduccion_inicializado() const {
    return m_motor_listo;
}

// --- Utilidades ---

std::vector<std::string> buscar_juegos_en_carpeta() {
    return GestorCarpetas::listar_juegos();
}

bool crear_carpeta_juegos_si_no_existe() {
    return GestorCarpetas::crear_carpeta_juegos();
}

std::string obtener_ruta_carpeta_juegos() {
    return GestorCarpetas::obtener_carpeta_juegos();
}

} // namespace Core
} // namespace chatPPSS4

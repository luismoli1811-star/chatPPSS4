import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    var ventana: UIWindow?
    
    func application(_ app: UIApplication, didFinishLaunchingWithOptions opts: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        ventana = UIWindow(frame: UIScreen.main.bounds)
        ventana?.rootViewController = VistaControlador()
        ventana?.makeKeyAndVisible()
        return true
    }
}

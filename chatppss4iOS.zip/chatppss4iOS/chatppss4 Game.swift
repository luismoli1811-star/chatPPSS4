import SwiftUI
import AVFoundation

struct chatPPSS4GameView: View {
    let nombreJuego: String
    let rutaJuego: String
    
    @StateObject private var gestorEstado = EstadoJuego()
    @State private var mostrarMenu = false
    @State private var tiempoTranscurrido: TimeInterval = 0
    @State private var ultimaActualizacion: Date = Date()
    
    // Temporizador de juego
    let temporizador = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    var body: some View {
        ZStack {
            // Fondo de pantalla completa
            Color.black
                .ignoresSafeArea()
            
            // Área de visualización del juego
            VistaPantallaJuego(gestor: gestorEstado)
            
            // Controles superpuestos
            if gestorEstado.estaEjecutando || gestorEstado.estaPausado {
                VStack {
                    HStack {
                        // Indicador de estado
                        HStack(spacing: 6) {
                            Circle()
                                .fill(gestorEstado.estaPausado ? Color.orange : Color.green)
                                .frame(width: 8, height: 8)
                            Text(gestorEstado.estaPausado ? "EN PAUSA" : "JUGANDO")
                                .font(.system(size: 11, weight: .bold))
                                .foregroundColor(.white)
                                .opacity(0.8)
                        }
                        .padding(.horizontal, 10)
                        .padding(.vertical, 5)
                        .background(Color.black.opacity(0.6))
                        .cornerRadius(8)
                        
                        Spacer()
                        
                        // Tiempo de juego
                        Text(formatearTiempo(tiempoTranscurrido))
                            .font(.system(size: 13, weight: .medium))
                            .foregroundColor(.white)
                            .opacity(0.7)
                        
                        Button(action: { mostrarMenu = true }) {
                            Image(systemName: "list.bullet.circle.fill")
                                .font(.system(size: 24))
                                .foregroundColor(.white.opacity(0.8))
                        }
                        .padding(.leading, 12)
                    }
                    .padding()
                    
                    Spacer()
                    
                    // Controles táctiles (ocultables)
                    if gestorEstado.mostrarControlesTactiles {
                        ControlesTactilesOverlay()
                            .padding(.bottom, 20)
                            .transition(.opacity)
                    }
                }
            }
            
            // Pantalla de carga / inicio
            if gestorEstado.estaCargando {
                VStack(spacing: 16) {
                    ProgressView()
                        .scaleEffect(1.5)
                    Text("Cargando \(nombreJuego)...")
                        .font(.system(size: 15))
                        .foregroundColor(.white)
                    Text("Motor: chat64iOS")
                        .font(.system(size: 12))
                        .foregroundColor(.gray)
                }
            }
        }
        .sheet(isPresented: $mostrarMenu) {
            MenuJuegoView(
                nombreJuego: nombreJuego,
                estaPausado: gestorEstado.estaPausado,
                alternarPausa: gestorEstado.alternarPausa,
                detenerJuego: gestorEstado.detener,
                alternarControles: gestorEstado.alternarControlesTactiles,
                controlesVisibles: gestorEstado.mostrarControlesTactiles
            )
        }
        .onAppear {
            gestorEstado.iniciar(nombre: nombreJuego, ruta: rutaJuego)
            ultimaActualizacion = Date()
        }
        .onDisappear {
            gestorEstado.detener()
        }
        .onReceive(temporizador) { _ in
            if gestorEstado.estaEjecutando {
                let ahora = Date()
                tiempoTranscurrido += ahora.timeIntervalSince(ultimaActualizacion)
                ultimaActualizacion = ahora
            }
        }
    }
    
    // Formato de tiempo: 00:00:00
    private func formatearTiempo(_ segundos: TimeInterval) -> String {
        let h = Int(segundos) / 3600
        let m = (Int(segundos) % 3600) / 60
        let s = Int(segundos) % 60
        return String(format: "%02d:%02d:%02d", h, m, s)
    }
}

// MARK: - Vista de Pantalla del Juego
struct VistaPantallaJuego: View {
    @ObservedObject var gestor: EstadoJuego
    
    var body: some View {
        ZStack {
            if gestor.estaEjecutando || gestor.estaPausado {
                // Área de renderizado (se conecta al núcleo nativo)
                Color.black
                    .overlay(
                        Text("Pantalla del juego")
                            .foregroundColor(.white.opacity(0.3))
                    )
            }
        }
        .animation(.easeInOut, value: gestor.estaCargando)
    }
}

// MARK: - Controles Táctiles Superpuestos
struct ControlesTactilesOverlay: View {
    var body: some View {
        VStack {
            Spacer()
            HStack {
                // Stick izquierdo
                ZStack {
                    Circle()
                        .fill(Color.gray.opacity(0.25))
                        .frame(width: 110, height: 110)
                    Circle()
                        .fill(Color.white.opacity(0.15))
                        .frame(width: 45, height: 45)
                }
                .padding(.leading, 20)
                
                Spacer()
                
                // Botones de acción
                VStack(spacing: 8) {
                    ButtonCircle(simbolo: "△", color: .yellow)
                    HStack(spacing: 24) {
                        ButtonCircle(simbolo: "□", color: .pink)
                        Spacer().frame(width: 30)
                        ButtonCircle(simbolo: "○", color: .red)
                    }
                    ButtonCircle(simbolo: "×", color: .blue)
                }
                .padding(.trailing, 20)
            }
        }
    }
}

// Botón circular individual
struct ButtonCircle: View {
    let simbolo: String
    let color: Color
    
    var body: some View {
        Circle()
            .fill(color.opacity(0.8))
            .frame(width: 55, height: 55)
            .overlay(
                Text(simbolo)
                    .font(.system(size: 22, weight: .bold))
                    .foregroundColor(.white)
            )
    }
}

// MARK: - Menú del Juego
struct MenuJuegoView: View {
    let nombreJuego: String
    let estaPausado: Bool
    let alternarPausa: () -> Void
    let detenerJuego: () -> Void
    let alternarControles: () -> Void
    let controlesVisibles: Bool
    
    @Environment(\.presentationMode) private var presentacion
    
    var body: some View {
        NavigationView {
            List {
                Section(header: Text(nombreJuego)) {
                    Button(action: {
                        alternarPausa()
                        presentacion.wrappedValue.dismiss()
                    }) {
                        HStack {
                            Image(systemName: estaPausado ? "play.circle.fill" : "pause.circle.fill")
                                .foregroundColor(.blue)
                            Text(estaPausado ? "Reanudar" : "Pausar")
                            Spacer()
                        }
                    }
                    
                    Button(action: alternarControles) {
                        HStack {
                            Image(systemName: controlesVisibles ? "gamecontroller" : "gamecontroller.slash")
                                .foregroundColor(.orange)
                            Text(controlesVisibles ? "Ocultar controles" : "Mostrar controles")
                            Spacer()
                        }
                    }
                    
                    Button(action: {
                        detenerJuego()
                        presentacion.wrappedValue.dismiss()
                    }) {
                        HStack {
                            Image(systemName: "stop.circle.fill")
                                .foregroundColor(.red)
                            Text("Cerrar juego")
                            Spacer()
                        }
                    }
                }
                
                Section {
                    Button("Cerrar menú") {
                        presentacion.wrappedValue.dismiss()
                    }
                }
            }
            .navigationTitle("Menú")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Listo") {
                        presentacion.wrappedValue.dismiss()
                    }
                }
            }
        }
    }
}

// MARK: - Gestor de Estado
class EstadoJuego: ObservableObject {
    @Published var estaCargando = true
    @Published var estaEjecutando = false
    @Published var estaPausado = false
    @Published var mostrarControlesTactiles = true
    
    func iniciar(nombre: String, ruta: String) {
        estaCargando = true
        // Simulación de carga → conectar con núcleo nativo
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { [weak self] in
            self?.estaCargando = false
            self?.estaEjecutando = true
        }
    }
    
    func alternarPausa() {
        guard estaEjecutando || estaPausado else { return }
        estaPausado.toggle()
    }
    
    func detener() {
        estaEjecutando = false
        estaPausado = false
        estaCargando = false
    }
    
    func alternarControlesTactiles() {
        mostrarControlesTactiles.toggle()
    }
}

// MARK: - Vista Previa
struct chatPPSS4GameView_Previews: PreviewProvider {
    static var previews: some View {
        chatPPSS4GameView(
            nombreJuego: "Juego de Prueba",
            rutaJuego: "/PS4/prueba.pkg"
        )
    }
}

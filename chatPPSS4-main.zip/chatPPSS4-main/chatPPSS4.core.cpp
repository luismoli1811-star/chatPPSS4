#include "chatPPSS4.core.h"
#include <iostream>
#include <sys/stat.h>
#include <dirent.h>

namespace chatPPSS4 {
namespace Core {

Emulador& Emulador::instancia() {
    static Emulador inst;
    return inst;
}

Emulador::Emulador()
    : m_estado(Estado::NoInicializado)
    , m_motor(MotorTraduccion::Ninguno)
    , m_motor_listo(false)
    , m_ejecutando(false) {
}

Emulador::~Emulador() {
    apagar();
}

bool Emulador::inicializar(MotorTraduccion motor) {
    if (m_estado != Estado::NoInicializado) return true;

    std::cout << "[" << NOMBRE << "] Iniciando versión " << VERSION 
              << " en " << PLATAFORMA << "\n";

    // Seleccionar e inicializar motor de traducción
    if (!establecer_motor(motor)) {
        std::cerr << "Error: No se pudo inicializar el motor de traducción\n";
        m_estado = Estado::Error;
        return false;
    }

    // Preparar carpeta de juegos
    if (!crear_carpeta_juegos_si_no_existe()) {
        std::cout << "Aviso: No se pudo crear/verificar carpeta de juegos\n";
    }

    m_estado = Estado::Listo;
    std::cout << "[" << NOMBRE << "] ✅ Listo — Motor: " << nombre_motor() << "\n";
    return true;
}

bool Emulador::establecer_motor(MotorTraduccion motor) {
    m_motor = motor;
    m_motor_listo = false;

    switch (m_motor) {
        case MotorTraduccion::FEX:
            std::cout << "  → Cargando FEX (mejor compatibilidad)...\n";
            // Aquí se inicializa la capa de FEX
            m_motor_listo = true; // Reemplazar por inicialización real
            break;

        case MotorTraduccion::Box64:
            std::cout << "  → Cargando Box64 (mayor velocidad)...\n";
            // Aquí se inicializa la capa de Box64
            m_motor_listo = true; // Reemplazar por inicialización real
            break;

        default:
            std::cerr << "  ⚠️ Motor de traducción no seleccionado\n";
            return false;
    }
    return m_motor_listo;
}

MotorTraduccion Emulador::motor_actual() const {
    return m_motor;
}

std::string Emulador::nombre_motor() const {
    switch (m_motor) {
        case MotorTraduccion::FEX: return "FEX";
        case MotorTraduccion::Box64: return "Box64";
        default: return "Ninguno";
    }
}

void Emulador::apagar() {
    if (m_ejecutando) detener();
    m_motor = MotorTraduccion::Ninguno;
    m_motor_listo = false;
    m_estado = Estado::NoInicializado;
    std::cout << "[" << NOMBRE << "] ⏹️ Apagado\n";
}

Estado Emulador::estado() const {
    return m_estado;
}

bool Emulador::cargar_juego(const std::string& ruta) {
    if (m_estado != Estado::Listo && m_estado != Estado::Pausado) return false;

    m_estado = Estado::Cargando;
    m_juego.ruta_archivo = ruta;

    // Aquí se analiza el archivo y se extrae información
    // (se amplía según formatos soportados)

    m_estado = Estado::Listo;
    std::cout << "[" << NOMBRE << "] Juego cargado: " << ruta << "\n";
    return true;
}

bool Emulador::iniciar_ejecucion() {
    if (m_estado != Estado::Listo) return false;
    if (!m_motor_listo) return false;

    m_ejecutando = true;
    m_estado = Estado::Ejecutando;
    std::cout << "[" << NOMBRE << "] ▶️ Ejecutando con " << nombre_motor() << "...\n";
    return true;
}

void Emulador::pausar() {
    if (m_estado == Estado::Ejecutando) {
        m_estado = Estado::Pausado;
        std::cout << "[" << NOMBRE << "] ⏸️ Pausado\n";
    }
}

void Emulador::reanudar() {
    if (m_estado == Estado::Pausado) {
        m_estado = Estado::Ejecutando;
        std::cout << "[" << NOMBRE << "] ▶️ Reanudado\n";
    }
}

void Emulador::detener() {
    m_ejecutando = false;
    m_estado = Estado::Listo;
    std::cout << "[" << NOMBRE << "] ⏹️ Detenido\n";
}

const JuegoInfo& Emulador::juego_actual() const {
    return m_juego;
}

std::string Emulador::resumen_estado() const {
    switch (m_estado) {
        case Estado::NoInicializado: return "No inicializado";
        case Estado::Listo: return "Listo";
        case Estado::Cargando: return "Cargando juego...";
        case Estado::Ejecutando: return "Ejecutando";
        case Estado::Pausado: return "En pausa";
        case Estado::Error: return "Error";
    }
    return "Desconocido";
}

// --- Utilidades ---

namespace {
    const std::string CARPETA_JUEGOS = "PS4/";

    bool es_archivo_juego(const std::string& nombre) {
        static const char* ext[] = {
            ".iso", ".pkg", ".ps4", ".card4", ".xps4",
            ".4iP", ".dic-ps4", ".PS4-RiP", ".vpp", ".claveagameps4",
            nullptr
        };
        for (int i = 0; ext[i]; ++i) {
            size_t len = strlen(ext[i]);
            if (nombre.size() > len &&
                nombre.substr(nombre.size() - len) == ext[i]) {
                return true;
            }
        }
        return false;
    }
}

std::vector<std::string> buscar_juegos_en_carpeta() {
    std::vector<std::string> lista;
    DIR* dir = opendir(CARPETA_JUEGOS.c_str());
    if (!dir) return lista;

    struct dirent* entrada;
    while ((entrada = readdir(dir)) != nullptr) {
        if (entrada->d_type == DT_REG) {
            std::string nombre = entrada->d_name;
            if (es_archivo_juego(nombre)) {
                lista.push_back(nombre);
            }
        }
    }
    closedir(dir);
    return lista;
}

bool crear_carpeta_juegos_si_no_existe() {
    struct stat st;
    if (stat(CARPETA_JUEGOS.c_str(), &st) == 0) {
        return S_ISDIR(st.st_mode);
    }
    return mkdir(CARPETA_JUEGOS.c_str(), 0755) == 0;
}

std::string obtener_ruta_carpeta_juegos() {
    return CARPETA_JUEGOS;
}

} // namespace Core
} // namespace chatPPSS4

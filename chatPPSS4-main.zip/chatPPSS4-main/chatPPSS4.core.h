#ifndef CHATPPSS4_CORE_H
#define CHATPPSS4_CORE_H

/**
 * @file chatPPSS4.core.h
 * @brief Núcleo principal del emulador chatPPSS4 — Versión Android
 * @details Usa FEX y Box64 como capas de traducción
 * @version 0.0.1
 * @date Septiembre 2026
 */

#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>
#include <functional>

namespace chatPPSS4 {
namespace Core {

// Versión
constexpr const char* NOMBRE = "chatPPSS4";
constexpr const char* VERSION = "0.0.1-Android";
constexpr const char* PLATAFORMA = "AArch64-Android";

// Estado del emulador
enum class Estado {
    NoInicializado,
    Listo,
    Cargando,
    Ejecutando,
    Pausado,
    Error
};

// Motor de traducción disponible
enum class MotorTraduccion {
    Ninguno,
    FEX,      // Mejor compatibilidad
    Box64     // Más velocidad
};

// Información del juego cargado
struct JuegoInfo {
    std::string titulo;
    std::string id_ps4;
    std::string ruta_archivo;
    std::string formato;
    uint64_t tamano_bytes;
    bool es_encriptado;
};

// Núcleo principal
class Emulador {
public:
    static Emulador& instancia();

    // Ciclo de vida
    bool inicializar(MotorTraduccion motor = MotorTraduccion::Box64);
    void apagar();
    Estado estado() const;

    // Carga y ejecución
    bool cargar_juego(const std::string& ruta);
    bool iniciar_ejecucion();
    void pausar();
    void reanudar();
    void detener();

    // Configuración del motor
    bool establecer_motor(MotorTraduccion motor);
    MotorTraduccion motor_actual() const;
    std::string nombre_motor() const;

    // Información
    const JuegoInfo& juego_actual() const;
    std::string resumen_estado() const;

private:
    Emulador();
    ~Emulador();
    Emulador(const Emulador&) = delete;
    Emulador& operator=(const Emulador&) = delete;

    Estado m_estado;
    MotorTraduccion m_motor;
    JuegoInfo m_juego;
    bool m_motor_listo;
    bool m_ejecutando;
};

// Utilidades
std::vector<std::string> buscar_juegos_en_carpeta();
bool crear_carpeta_juegos_si_no_existe();
std::string obtener_ruta_carpeta_juegos();

} // namespace Core
} // namespace chatPPSS4

#endif // CHATPPSS4_CORE_H
